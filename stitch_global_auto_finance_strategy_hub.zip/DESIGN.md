---
name: Global Expansion Intelligence System
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c6d1'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8d909a'
  outline-variant: '#43474f'
  surface-tint: '#abc7ff'
  primary: '#abc7ff'
  on-primary: '#052f62'
  primary-container: '#002c5f'
  on-primary-container: '#7695ce'
  inverse-primary: '#3f5e94'
  secondary: '#ffb4a5'
  on-secondary: '#650b00'
  secondary-container: '#d02200'
  on-secondary-container: '#ffe7e2'
  tertiary: '#56d5ff'
  on-tertiary: '#003544'
  tertiary-container: '#003240'
  on-tertiary-container: '#00a2c8'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#abc7ff'
  on-primary-fixed: '#001b3f'
  on-primary-fixed-variant: '#25467a'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a5'
  on-secondary-fixed: '#3e0400'
  on-secondary-fixed-variant: '#8e1400'
  tertiary-fixed: '#b8eaff'
  tertiary-fixed-dim: '#56d5ff'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004d61'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  stat-lg:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1600px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is engineered for executive-level decision-making within a global financial context. The brand personality is authoritative, precise, and forward-thinking, reflecting the legacy of a global automotive finance leader. 

The visual style blends **Corporate Modern** professionalism with **Glassmorphism** to create a sense of depth and data transparency. By utilizing high-end frosted surfaces against a deep, structural background, the UI evokes a high-tech "Command Center" atmosphere. The aesthetic prioritizes clarity and high-density information without sacrificing the premium feel expected by C-suite stakeholders.

## Colors
The palette is anchored in the deep automotive legacy of the brand. 
- **Primary (Deep Navy):** Used for the structural foundation and high-level navigation, providing a grounded, institutional feel.
- **Secondary (Hyundai Red):** Reserved strictly for critical data points, alerts, and high-priority AI insights. It should be used sparingly to maintain its impact.
- **Tertiary (Financial Blue):** Applied to interactive elements, active states, and simulation progress indicators.
- **Neutrals:** A range of sophisticated greys facilitate visual hierarchy within data-heavy tables.
- **Glass Effect:** Surfaces utilize a high-refraction blur (20px-40px) with a subtle 1px border to define boundaries without heavy shadows.

## Typography
The typography strategy leverages **Hanken Grotesk** for its sharp, contemporary geometry in headlines and data callouts. **Inter** provides maximum legibility for long-form analytical reports and tooltips. 

A specific inclusion of **JetBrains Mono** for labels and technical metadata reinforces the dashboard's "AI-driven" and "Simulation" nature. Use uppercase for mono-labels to provide a structural, industrial feel. Ensure all financial figures use tabular lining to ensure digits align vertically in data tables.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for the main content area, with a fixed-width 280px sidebar for global navigation. 

- **Data Density:** While executive dashboards require high visibility, generous whitespace (40px margins) must be maintained to prevent cognitive overload.
- **Mobile Adaptation:** On mobile, the 12-column grid collapses to a 2-column grid. Complex data visualizations should provide a simplified "Summary Card" view with an option to view the full chart in landscape mode.
- **Vertical Rhythm:** A strict 8px baseline grid is used to align all components, ensuring the "sharp" and "precise" feel requested.

## Elevation & Depth
Depth is created through **Tonal Layering** and **Glassmorphism** rather than traditional drop shadows.

- **Level 0 (Base):** Pure Navy/Black background (#050B14).
- **Level 1 (Panels):** Semi-transparent white (4% opacity) with a 1px solid stroke (10% opacity) and 30px backdrop blur.
- **Level 2 (Active States/Modals):** Increased transparency (8% opacity) with a subtle inner glow on the top edge to simulate overhead light.
- **Interactive Elements:** Buttons and toggles use a slight saturation increase on hover rather than an elevation lift.

## Shapes
To maintain a high-end, professional feel, the design system utilizes **Soft (0.25rem)** roundedness. This provides a modern touch while maintaining the "Sharp Edges" and "Sophisticated" requirement. 

- **Standard Elements:** 4px radius (Buttons, Inputs, Small Cards).
- **Large Containers:** 8px radius (Main Simulation Maps, Large Data Panels).
- **Data Points:** Circles in charts remain sharp or use minimal 2px rounding.

## Components
- **Simulation Controls:** Use slim sliders with high-contrast active tracks in Tertiary Blue. Toggle switches should be rectangular with sharp corners.
- **Glass Cards:** Every card must have a 1px border `rgba(255, 255, 255, 0.1)` to ensure separation from the dark background.
- **Interactive Maps:** Use a monochromatic dark base map with neon-pulse markers for expansion regions. Use Tertiary Blue for active regions and Secondary Red for high-risk zones.
- **AI Agent Progress:** Display as a thin, 2px horizontal line with a glowing leading edge. Avoid "bubbly" loading icons.
- **Buttons:**
    - *Primary:* Solid Deep Navy with a white label and 1px white border.
    - *Secondary:* Ghost style with white text and subtle glass background.
- **Data Tables:** No vertical lines. Use subtle horizontal dividers (5% white). Header rows use `label-mono` typography in all caps.